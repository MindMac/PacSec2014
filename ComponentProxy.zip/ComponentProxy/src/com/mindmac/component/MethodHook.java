package com.mindmac.component;

import java.util.Arrays;

import android.util.Log;


import de.robv.android.xposed.XC_MethodHook.MethodHookParam;


/***
 * 
 * @author Wenjun Hu
 * 
 * Abstract base class of hooked method
 *
 ***/


public abstract class MethodHook {
	private String mClassName;
	private String mMethodName;
	private boolean mLogTrace;
	
	protected MethodHook(String className, String methodName){
		mClassName = className;
		mMethodName = methodName;
	}
	

	public String getClassName(){
		return mClassName;
	}
	
	public String getMethodName(){
		return mMethodName;
	}

	
	public void before(MethodHookParam param) throws Throwable {
		// Do nothing
	}

	public void after(MethodHookParam param) throws Throwable {
		// Do nothing
	}
	

}
