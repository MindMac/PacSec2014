package com.mindmac.component;

import android.os.Process;

public class Util {
	public static boolean isApplication(int uid) {
		return (uid >= Process.FIRST_APPLICATION_UID && uid <= Process.LAST_APPLICATION_UID);
	}
}
