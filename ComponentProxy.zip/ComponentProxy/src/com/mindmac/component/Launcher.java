package com.mindmac.component;


import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

import android.annotation.SuppressLint;
import android.os.Process;

import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XC_MethodHook;
import static de.robv.android.xposed.XposedHelpers.findClass;

//This class will be called by Xposed
@SuppressLint("DefaultLocale")
public class Launcher implements IXposedHookLoadPackage, IXposedHookZygoteInit {
	
	
	// Called when zygote initialize
	public void initZygote(StartupParam startupParam) throws Throwable {
		
		hookNonSystemServices();

	}

	// Hook methods not provided by system services
	private void hookNonSystemServices(){
		// Application
		hookAll(ApplicationHook.getMethodHookList());
	
		
	}
	

	private static void hookAll(List<MethodHook> methodHookList) {
		for (MethodHook methodHook : methodHookList)
			hook(methodHook);
	}

	private static void hook(MethodHook methodHook) {
		hook(methodHook, null);
	}


	private static void hook(final MethodHook methodHook, ClassLoader classLoader) {
		try {
			
			// Create hook method
			XC_MethodHook xcMethodHook = new XC_MethodHook() {
				@Override
				protected void beforeHookedMethod(MethodHookParam param) throws Throwable {
					try {
						if (Process.myUid() <= 0)
							return;
						methodHook.before(param);
					} catch (Throwable ex) {
						throw ex;
					}
				}

				@Override
				protected void afterHookedMethod(MethodHookParam param) throws Throwable {
					if (!param.hasThrowable())
						try {
							if (Process.myUid() <= 0)
								return;
							methodHook.after(param);
						} catch (Throwable ex) {
							throw ex;
						}
				}
			};

			
			// Find hook class
			Class<?> hookClass = findClass(methodHook.getClassName(), classLoader);
			if (hookClass == null)
				return;
			

			// Add hook
			if (methodHook.getMethodName() == null) {
				for (Constructor<?> constructor : hookClass.getDeclaredConstructors()){
					XposedBridge.hookMethod(constructor, xcMethodHook);
				}
			} else{
				for (Method method : hookClass.getDeclaredMethods())
					if (method.getName().equals(methodHook.getMethodName()))
						XposedBridge.hookMethod(method, xcMethodHook);
			}
			
		} catch (Throwable ex) {
			
		}
	}

	@Override
	public void handleLoadPackage(LoadPackageParam lpparam) throws Throwable {
		// TODO Auto-generated method stub
		
	}
}
