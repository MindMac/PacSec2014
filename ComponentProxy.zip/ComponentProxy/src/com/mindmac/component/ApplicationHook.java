package com.mindmac.component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Process;

import de.robv.android.xposed.XC_MethodHook.MethodHookParam;

public class ApplicationHook extends MethodHook {
	private static final String mClassName = "android.app.Application";
	private Methods mMethod = null;
	
	private static boolean mReceiverInstalled = false;

	private static final String PKG_NAME_EXTRA = "pkg";
	private static final String TYPE_EXTRA = "type";
	private static final String ACTION_EXTRA = "action";
	private static final String FLAGS_EXTRA = "flags";
	private static final String CLASS_EXTRA = "class";
	
	public static String ACTION_LAUNCHER = "com.mindmac.component.LAUNCHER";

	public ApplicationHook(Methods method) {
		super(mClassName, method.name());
		mMethod = method;
	}

	// public void onCreate()
	// frameworks/base/core/java/android/app/Application.java
	// http://developer.android.com/reference/android/app/Application.html

	private enum Methods {
		onCreate
	};
	
	private enum LauncherType{
		Activity, Service, Receiver
	};

	public static List<MethodHook> getMethodHookList() {
		List<MethodHook> methodHookList = new ArrayList<MethodHook>();
		methodHookList.add(new ApplicationHook(Methods.onCreate));
		return methodHookList;
	}
	
	@Override
	public void after(MethodHookParam param) throws Throwable {
		if (mMethod == Methods.onCreate) {
			System.out.println("Application onCreate");
			// Install receiver for package management
			if (Util.isApplication(Process.myUid()) && !mReceiverInstalled)
				try {
					Application app = (Application) param.thisObject;
					if (app != null) {
						mReceiverInstalled = true;
						app.registerReceiver(new Receiver(app), new IntentFilter(ACTION_LAUNCHER));
					}
				} catch (SecurityException ignored) {
				} catch (Throwable ex) {
				}
		}

	}

	private class Receiver extends BroadcastReceiver {
		public Receiver(Application app) {
		}

		@Override
		public void onReceive(Context context, Intent intent) {
			try {
				
				String launcherAction = intent.getAction();
				if(!launcherAction.equals(ACTION_LAUNCHER))
					return;
				
				Bundle bundle = intent.getExtras();
				if(bundle != null){
					String pkgName = bundle.getString(PKG_NAME_EXTRA);
					if(pkgName == null)
						return;
					
					String thisPkgName = context.getPackageName();
					if(!pkgName.equals(thisPkgName))
						return;
					
					String launcherType = bundle.getString(TYPE_EXTRA);
					System.out.println("LauncherType: " + launcherType);
					if(launcherType == null)
						return;
					
					String action = bundle.getString(ACTION_EXTRA);
					System.out.println("Action: " + action);
					int flags = -1;
					if(launcherType.equals(LauncherType.Activity.name())){
						String tmpFlags = bundle.getString(FLAGS_EXTRA);
						if(tmpFlags != null){
							try{
								flags = Integer.parseInt(tmpFlags);
							}catch(NumberFormatException ex){
								
							}	
						}
					}
					
					String className = bundle.getString(CLASS_EXTRA);
					System.out.println("ClassName: " + className);
					
					// Remove redundant extras
					bundle.remove(PKG_NAME_EXTRA);
					bundle.remove(TYPE_EXTRA);
					bundle.remove(ACTION_EXTRA);
					bundle.remove(FLAGS_EXTRA);
					bundle.remove(CLASS_EXTRA);
					
					// Build intent
					Intent innerIntent = new Intent();
					innerIntent.setAction(action);
					innerIntent.putExtras(bundle);
					if(className != null)
						innerIntent.setClassName(thisPkgName, className);
					
					// Launcher Component
					if(launcherType.equals(LauncherType.Activity.name())){
						innerIntent.setFlags(flags);
						innerIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						context.startActivity(innerIntent);
						System.out.println("Start Activity");
					}else if(launcherType.equals(LauncherType.Service.name())){
						context.startService(innerIntent);
						System.out.println("Start Service");
					}else if(launcherType.equals(LauncherType.Receiver.name())){
						context.sendBroadcast(innerIntent);	
						System.out.println("Start Receiver");
					}
				}
				
			} catch (Throwable ex) {
				ex.printStackTrace();
			}
		}
	}
}
